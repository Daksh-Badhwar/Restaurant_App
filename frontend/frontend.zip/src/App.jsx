import React from 'react';
import Header from "./components/Layout/Header";
import './App.css'
function App() {
  return(
  <>
  <h1>Hi</h1>
  <Header/>
  </>
  )
}

export default App;
